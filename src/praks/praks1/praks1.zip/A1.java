package praks1;

public class A1 {
  public static void main(String[] args) {
    System.out.println("Tere, maailm!");
	System.out.print("Tere, põrgu!");
	System.out.println("Tere, universum!");

  }
}