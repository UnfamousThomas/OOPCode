package praks1;

public class Tere {
  public static void main(String[] args) {
    System.out.println("Tere, maailm!");

  }
}