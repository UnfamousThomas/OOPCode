package praks1;

public class A3 {
  public static void main(String[] args) {
	int a = 5 + 7;
	if(a < 10) {
		System.out.println("A on väiksem kui 10");
	} else {
		System.out.println("A ei ole väiksem kui 10");
	}
    System.out.println("Tere, maailm!");
  }
}